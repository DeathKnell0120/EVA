<template>
  <div id="app">
    <BarNav></BarNav>
    <img alt="Vue logo" src="./assets/eva-logo.png" id="estaimg">
    <div id="micompo"><HelloWorld align="center" msg="EVA THE BEST BETWEEN THE BEST GONORREAS"/></div>
    <Services></Services>
    <MiComponente></MiComponente>
    
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'
import MiComponente from './components/MiComponente.vue'
import BarNav from './components/BarNav.vue'
import Services from './components/Services.vue'

export default {
  name: 'App',
  components: {
    HelloWorld,
    MiComponente,
    BarNav,
    Services
  }
}
</script>

<style>
@import './assets/css/styles.css';
@import './assets/css/contact-compi.css';
</style>
